# 2023-noturna-chrome-extension
Noturna is a Chrome Extension that improves web browsing for low vision users by turning HTML backgrounds black and text and foreground elements white, resulting in high-contrast viewing and easier navigation.
